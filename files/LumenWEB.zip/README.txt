Thanks for downloading LumenWEB!

This egg is completely free to use.

Import this egg to your Pterodactyl panel as you would normally, and create a server with it. The installation is as simple as that!

Made with love by david1117dev.